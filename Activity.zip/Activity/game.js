$(document).ready(function() {
    const app = {

        
        questions: [
            { 
                question: "Magbigay ng salitang pwedeng pang-describe sa saging?", 
                answers: [["Mahaba", 43], ["Masarap", 10], ["Matamis", 9], ["Dilaw", 6], ["Malambot", 4]]
            },
            { 
                question: "Mahirap maging __________?", 
                answers: [["Pogi", 60], ["Mahirap", 17], ["Mabait", 4], ["Pangit", 4], ["Single", 3]]
            },
            { 
                question: "Anong mga pambobola ang sinasabi ng lalaki sa babae?", 
                answers: [["Ang ganda mo", 32], ["Ikaw lang wala na", 31], ["Di kita iiwan", 8], ["I miss you", 8], ["Ang sexy mo", 3]]
            },
            { 
                question: "Magbigay ng tunog na nalilikha ng katawan?", 
                answers: [["Utot", 24], ["Boses", 14], ["Sipol", 10], ["Hilik", 9], ["Palakpak", 8]]
            },
            { 
                question: "Sino kinakausap mo pag may problem ka sa lovelife?", 
                answers: [["Friend", 51], ["Parents", 13], ["Kapatid", 6], ["Sarili", 4], ["Lord", 3]]
            }
        ],
        teamScores: { team1: 0, team2: 0 },
        currentQuestionIndex: 0,
        currentTeam: 1,
        incorrectGuesses: { team1: 0, team2: 0 }, // Track incorrect guesses for each team
        maxIncorrectGuesses: 3,
        revealedAnswers: [],
        totalRounds: 5,

        init: function() {
            this.correctSound = document.getElementById('correctSound');
            this.wrongSound = document.getElementById('wrongSound');

            $('#startGame').on('click', this.startGame.bind(this));
            $('#submitAnswer').on('click', this.checkAnswer.bind(this));
            $('#nextRound').on('click', this.nextRound.bind(this));
            this.prepareAnswerBoxes();
        },

        startGame: function() {
            const team1Name = prompt("Enter the name for Team 1:") || "Team 1";
            const team2Name = prompt("Enter the name for Team 2:") || "Team 2";
            $('#teamNames').html(`<h2>${team1Name} vs ${team2Name}</h2>`);
            $('#gameBoard').show();
            this.showQuestion();
        },

        showQuestion: function() {
            const question = this.questions[this.currentQuestionIndex];
            $('#question').text(question.question);
            $('#userAnswer').val(""); // Clear the input
            this.incorrectGuesses.team1 = 0; // Reset incorrect guesses for Team 1
            this.incorrectGuesses.team2 = 0; // Reset incorrect guesses for Team 2
            this.revealedAnswers = []; // Reset revealed answers
            this.prepareAnswerBoxes(); // Prepare answer boxes for the current question
        },

        checkAnswer: function() {
            const userAnswer = $('#userAnswer').val().toLowerCase().trim();
            const question = this.questions[this.currentQuestionIndex];
            const correctAnswers = question.answers.map(ans => ans[0].toLowerCase());
            const answerIndex = correctAnswers.indexOf(userAnswer);

            // Check if the answer is correct
            if (answerIndex !== -1 && !this.revealedAnswers.includes(userAnswer)) {
                this.correctSound.play(); // Play correct sound in advance
                setTimeout(() => {
                    alert("Correct answer!");
                }, 1000); // Delay alert for 1 second
                this.updateScore(answerIndex);
                this.revealAnswer(answerIndex);
            } else {
                this.wrongSound.play(); // Play wrong sound in advance
                setTimeout(() => {
                    alert("Incorrect answer! Switching to Team " + (this.currentTeam === 1 ? 2 : 1) + "'s turn.");
                    this.switchTeam();
                }, 1000); // Delay alert for 1 second
                this.incorrectGuesses[`team${this.currentTeam}`]++; // Increment the current team's incorrect guesses
                this.addStrike(); // Add strike for the incorrect answer

                if (this.incorrectGuesses[`team${this.currentTeam}`] >= this.maxIncorrectGuesses) {
                    this.endRound();
                    return;
                }
            }

            // Check if all answers are revealed
            if (this.revealedAnswers.length === question.answers.length) {
                this.endRound();
            }
        },

        updateScore: function(answerIndex) {
            const score = this.questions[this.currentQuestionIndex].answers[answerIndex][1];
            if (this.currentTeam === 1) {
                this.teamScores.team1 += score;
                $('#team1Score').text("Team 1: " + this.teamScores.team1);
            } else {
                this.teamScores.team2 += score;
                $('#team2Score').text("Team 2: " + this.teamScores.team2);
            }
        },

        revealAnswer: function(answerIndex) {
            const answer = this.questions[this.currentQuestionIndex].answers[answerIndex];
            const answerText = answer[0]; // Get the answer text
            const score = answer[1]; // Get the score
            this.revealedAnswers.push(answerText.toLowerCase());
            $(`#answer${answerIndex}`).addClass('revealed').text(`${answerText} (${score} points)`); // Display answer with points
        },

        revealAllAnswers: function() {
            const question = this.questions[this.currentQuestionIndex];
            question.answers.forEach((ans, index) => {
                const answerText = ans[0]; // Get the answer text
                const score = ans[1]; // Get the score
                $(`#answer${index}`).addClass('revealed').text(`${answerText} (${score} points)`); // Display answer with points
            });
        },

        switchTeam: function() {
            this.currentTeam = this.currentTeam === 1 ? 2 : 1;
            alert("It's now Team " + this.currentTeam + "'s turn!");
        },

        endRound: function() {
            alert("Round Over! Revealing all answers...");
            this.revealAllAnswers();
            this.showRoundWinner();
            $('#nextRound').show(); // Show the next round button after the round ends
        },

        showRoundWinner: function() {
            const roundWinner = this.teamScores.team1 > this.teamScores.team2 ? "Team 1" : "Team 2";
            const roundScore = `Team 1: ${this.teamScores.team1} | Team 2: ${this.teamScores.team2}`;
            alert(`Round Winner: ${roundWinner}\nScores: ${roundScore}`);
        },

        nextRound: function() {
            this.currentQuestionIndex++;
            $('#nextRound').hide(); // Hide the next round button
            this.resetStrikes(); // Reset the strikes
            if (this.currentQuestionIndex < this.totalRounds) {
                this.showQuestion(); // Show next question
            } else {
                this.endGame();
            }
        },

        endGame: function() {
            const winner = this.teamScores.team1 > this.teamScores.team2 ? "Team 1" : "Team 2";
            alert(`Game Over! Final Scores:\nTeam 1: ${this.teamScores.team1}\nTeam 2: ${this.teamScores.team2}\nThe winner is ${winner}!`);
            $('#gameBoard').hide();
        },

        prepareAnswerBoxes: function() {
            const question = this.questions[this.currentQuestionIndex];
            const answerBoxes = question.answers.map((ans, index) => `<div id="answer${index}" class="answer-box">?????</div>`).join('');
            $('.answer-boxes').html(answerBoxes);
        },

        addStrike: function() {
            const strike = '<span class="strike">❌</span>';
            if (this.currentTeam === 1) {
                $('#team1Strikes').append(strike);
            } else {
                $('#team2Strikes').append(strike);
            }
        },

        resetStrikes: function() {
            $('#team1Strikes').html("Strikes: "); // Clear Team 1 strikes
            $('#team2Strikes').html("Strikes: "); // Clear Team 2 strikes
            this.incorrectGuesses.team1 = 0; // Reset incorrect guesses for Team 1
            this.incorrectGuesses.team2 = 0; // Reset incorrect guesses for Team 2
        }
    };

    app.init();
});
