
// Declare variables
let playerScores = { team1: 0, team2: 0 };
let currentRound = 1;
let totalRounds = 5;
let correctAnswers = ['Hello', 'World', 'Antok', 'Me'];
let playerNames = { team1: '', team2: '' };
let countdownInterval;

// Event listener for Start Game button
document.getElementById('start-game').addEventListener('click', startGame);

// Initialize the game
function startGame() {
    playerNames.team1 = document.getElementById('player1-name').value;
    playerNames.team2 = document.getElementById('player2-name').value;
    document.querySelector('.score-table thead th:nth-child(1)').innerText = playerNames.team1;
    document.querySelector('.score-table thead th:nth-child(2)').innerText = playerNames.team2;

    currentRound = 1;
    playerScores.team1 = 0;
    playerScores.team2 = 0;
    updateScores();
    startCountdown();
}

// Validate the user's answer
document.getElementById('answer-form').addEventListener('submit', function(e) {
    e.preventDefault();
    let userAnswer = document.getElementById('user-answer').value;
    validateAnswer(userAnswer);
});

// Function to validate answers
function validateAnswer(userAnswer) {
    if (correctAnswers.includes(userAnswer)) {
        displayCorrectAnswer(userAnswer);
    } else {
        alert('Incorrect answer!');
    }
}

// Display correct answer in results section
function displayCorrectAnswer(answer) {
    document.getElementById('result').innerHTML += `<p>Correct Answer: ${answer}</p>`;
    // Update score for correct answer (example logic)
    if (answer === correctAnswers[0]) {
        playerScores.team1 += 10; // Assign points to team 1
    } else {
        playerScores.team2 += 5; // Assign points to team 2
    }
    updateScores();
}

// Countdown timer function
function startCountdown() {
    let timeLeft = 10;
    document.getElementById('countdown-timer').style.display = 'block';
    document.getElementById('countdown-timer').innerText = timeLeft;
    
    countdownInterval = setInterval(function() {
        timeLeft--;
        document.getElementById('countdown-timer').innerText = timeLeft;
        document.getElementById('time-left').value = 10 - timeLeft; // Update progress bar
        if (timeLeft <= 0) {
            clearInterval(countdownInterval);
            alert('Time is up!');
        }
    }, 1000);
}

// Function to update player scores in score table
function updateScores() {
    document.getElementById('score-team1').innerText = playerScores.team1;
    document.getElementById('score-team2').innerText = playerScores.team2;
}

// Handle Pass and Play buttons
document.getElementById('pass-button').addEventListener('click', function() {
    alert('You chose to pass!');
    // Logic for passing the turn can be added here
});

document.getElementById('play-button').addEventListener('click', function() {
    alert('You chose to play!');
    // Logic for continuing the game can be added here
});

// Use console.log to debug progress
console.log('Game script loaded successfully.');