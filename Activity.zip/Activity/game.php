<?php
// Start session to store player details
session_start();

// Database connection
$servername = "localhost";
$username = "root"; // Adjust as per your database credentials
$password = ""; // Adjust as per your database credentials
$dbname = "family_feud_game"; // The name of the database

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check the database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to sanitize and validate user input to prevent SQL injection
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if form is submitted (from answer form)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $playerName = sanitize_input($_POST['player-name']);
    $score = intval($_POST['score']); // Make sure score is an integer
    $gameDate = date("Y-m-d H:i:s");

    // Insert player names and scores into the database
    $stmt = $conn->prepare("INSERT INTO scores (playerName, score, gameDate) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $playerName, $score, $gameDate);
    
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Function to fetch and display scores
function displayScores($conn) {
    $sql = "SELECT * FROM scores ORDER BY score DESC";
    $result = $conn->query($sql);
    
    echo "<table><tr><th>Player</th><th>Score</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row['playerName'] . "</td><td>" . $row['score'] . "</td></tr>";
    }
    echo "</table>";
}

// Display scores
displayScores($conn);

// Close the database connection
$conn->close();
?>