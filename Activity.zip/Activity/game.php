<?php
// Database configuration
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "activity_familyfeud"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if POST data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and retrieve team names
    $team1_name = isset($_POST['team1_name']) ? $conn->real_escape_string($_POST['team1_name']) : "Team 1";
    $team2_name = isset($_POST['team2_name']) ? $conn->real_escape_string($_POST['team2_name']) : "Team 2";

    // SQL query to insert team names
    $sql = "INSERT INTO teams (team1, team2) VALUES ('$team1_name', '$team2_name')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "Teams successfully registered: $team1_name vs $team2_name";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>
